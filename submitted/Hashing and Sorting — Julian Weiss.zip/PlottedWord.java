//Created by Julian Weiss for CSC172
//Part of the Hashing and Sorting project
public class PlottedWord{
	public String word;
	public int line, wordNumber;
	
	public PlottedWord(String givenWord, int givenLine, int givenNumber){
		word = givenWord;
		line = givenLine;
		wordNumber = givenNumber;
	}//end constructor
}//end class